import json
import sqlite3
import os
from datetime import datetime


class ResumeStorage:
    def __init__(self, db_path="candidates.db", json_path="candidates.json"):
        self.db_path = db_path
        self.json_path = json_path
        self._init_db()

    def _init_db(self):
        """Initialize the SQLite database schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Create Candidates table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS candidates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT,
                phone_no TEXT,
                experience_in_years REAL,
                skills TEXT,
                raw_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Create Companies table (one-to-many with candidates)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                candidate_id INTEGER,
                company_name TEXT,
                role TEXT,
                job_responsibilities TEXT,
                FOREIGN KEY (candidate_id) REFERENCES candidates (id)
            )
        ''')

        # Create Projects table (one-to-many with candidates)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                candidate_id INTEGER,
                project_name TEXT,
                project_description TEXT,
                FOREIGN KEY (candidate_id) REFERENCES projects (id)
            )
        ''')

        conn.commit()
        conn.close()

    def save_to_json(self, data):
        """Append candidate data to a local JSON file."""
        existing_data = []
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                existing_data = []

        data_to_store = data.copy()
        data_to_store['processed_at'] = datetime.now().isoformat()
        existing_data.append(data_to_store)

        with open(self.json_path, 'w', encoding='utf-8') as f:
            json.dump(existing_data, f, indent=4)
        print(f"-> Saved to JSON: {self.json_path}")

    def save_to_sqlite(self, data):
        """Save candidate, companies, and projects to SQLite."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        try:
            # Skills stored as JSON array string
            skills_json = json.dumps(data.get("skills", []))

            cursor.execute('''
                INSERT INTO candidates (
                    name, email, phone_no, experience_in_years,
                    skills, raw_json
                ) VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                data.get("name"),
                data.get("email"),
                data.get("phone_no"),
                data.get("experience_in_years"),
                skills_json,
                json.dumps(data)
            ))

            candidate_id = cursor.lastrowid

            # Insert companies
            for company in data.get("companies", []):
                cursor.execute('''
                    INSERT INTO companies (
                        candidate_id, company_name, role, job_responsibilities
                    ) VALUES (?, ?, ?, ?)
                ''', (
                    candidate_id,
                    company.get("company_name"),
                    company.get("role"),
                    company.get("job_responsibilities")
                ))

            # Insert projects
            for project in data.get("projects", []):
                cursor.execute('''
                    INSERT INTO projects (
                        candidate_id, project_name, project_description
                    ) VALUES (?, ?, ?)
                ''', (
                    candidate_id,
                    project.get("project_name"),
                    project.get("project_description")
                ))

            conn.commit()
            print(f"-> Saved to SQLite: {self.db_path} (Candidate ID: {candidate_id})")

        except Exception as e:
            conn.rollback()
            print(f"Error saving to SQLite: {e}")
        finally:
            conn.close()
