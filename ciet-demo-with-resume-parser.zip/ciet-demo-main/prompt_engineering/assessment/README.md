# AI Resume Parser — Assessment Submission

## What This Is

A resume parsing pipeline built for the `prompt_engineering/assessment/` task.
It mirrors the `invoice_parser` demo exactly — same folder structure, same
3-step pipeline, same 7-component prompt framework — but applied to resumes
instead of invoices.

---

## Folder Structure

```
prompt_engineering/
└── assessment/
    ├── README.md               ← This file
    ├── resume_parser.py        ← Main pipeline script
    ├── resume_storage.py       ← SQLite + JSON storage layer
    ├── view_db.py              ← CLI tool to query candidates.db
    ├── prompt_guide.md         ← Bad vs Good prompt breakdown
    └── resumes/                ← Put your resume PDFs here
```

---

## Setup

### 1. Install dependencies

```bash
pip install pdfplumber google-genai python-dotenv
```

### 2. Set your API key

Create a `.env` file in this folder:

```
GOOGLE_API_KEY=your_key_here
```

### 3. Add resume PDFs

Put your PDF resumes in a `resumes/` folder:

```
assessment/
└── resumes/
    ├── resume_alice.pdf
    ├── resume_bob.pdf
    └── ...
```

---

## Running

### Single resume
```bash
python resume_parser.py resumes/resume_alice.pdf
```

### Batch (entire folder)
```bash
python resume_parser.py ./resumes/
```

### View results
```bash
python view_db.py             # Summary table of all candidates
python view_db.py --full      # Full profile for every candidate
python view_db.py --id 1      # Full profile for candidate with ID 1
```

---

## Pipeline Steps

For each PDF the script runs three steps:

```
Step 1 — PDF OCR          (pdfplumber)
    ↓  raw text
Step 2 — LLM Parsing      (Gemini gemini-2.5-flash, 7-component prompt)
    ↓  structured JSON
Step 3 — Storage          (candidates.json  +  candidates.db SQLite)
```

Each step saves intermediate files into `results_<filename>/`:

```
results_resume_alice/
├── step_1_ocr/
│   └── raw_extracted_text.txt
├── step_2_llm/
│   └── parsed_candidate.json
└── step_3_storage/
    └── storage_log.txt
```

---

## Extracted Fields

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Candidate's full name |
| `email` | string | Contact email |
| `phone_no` | string | Contact phone (preserves country code) |
| `experience_in_years` | number | Total professional experience |
| `skills` | string[] | Flat list of skills |
| `companies[].company_name` | string | Organization name |
| `companies[].role` | string | Job title |
| `companies[].job_responsibilities` | string | Key responsibilities |
| `projects[].project_name` | string | Project title |
| `projects[].project_description` | string | Overview and tools used |

---

## Database Schema

```
candidates
├── id (PK)
├── name
├── email
├── phone_no
├── experience_in_years
├── skills (JSON array stored as text)
├── raw_json
└── created_at

companies
├── id (PK)
├── candidate_id (FK → candidates.id)
├── company_name
├── role
└── job_responsibilities

projects
├── id (PK)
├── candidate_id (FK → candidates.id)
├── project_name
└── project_description
```

---

## Prompt Framework

See `prompt_guide.md` for a full breakdown of the **7-component framework**
and a Bad vs. Good prompt comparison.

The 7 components used:
1. **Role** — Senior HR Data Analyst
2. **Task** — Extract structured candidate profile
3. **Context** — Automated ATS pipeline
4. **Input** — Delimited OCR text
5. **Format** — Strict JSON schema
6. **Constraints** — No preamble, numeric types enforced, flat arrays
7. **Examples** — One few-shot example anchoring date-to-years conversion
