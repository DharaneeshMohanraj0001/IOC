"""
Resume Parser — Prompt Engineering Assessment
=============================================
Mirrors the invoice_parser.py structure from the prompt_engineering/invoice_parser/ demo.

Pipeline:
  Step 1 → PDF text extraction with pdfplumber
  Step 2 → LLM parsing with Gemini using the 7-component prompt framework
  Step 3 → Storage to candidates.json and candidates.db (SQLite)

Usage:
  python resume_parser.py <path_to_pdf>
  python resume_parser.py <path_to_directory_of_pdfs>
"""

import pdfplumber
import json
import os
import sys
import re
from dotenv import load_dotenv
from google import genai
from google.genai.types import HttpOptions
from resume_storage import ResumeStorage

load_dotenv()

if os.getenv("GOOGLE_API_KEY") is None:
    print("Error: GOOGLE_API_KEY environment variable is not set.")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Step 1 — PDF Text Extraction
# ---------------------------------------------------------------------------

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extracts raw text from a resume PDF using pdfplumber."""
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        print(f"Error reading PDF: {e}")
        sys.exit(1)
    return text


# ---------------------------------------------------------------------------
# Step 2 — LLM Parsing (7-Component Prompt Framework)
# ---------------------------------------------------------------------------

def clean_json_response(response_text: str) -> str:
    """Strips markdown code fences from the Gemini response."""
    json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
    if json_match:
        return json_match.group(1)

    # Fallback: find first '{' and last '}'
    start = response_text.find('{')
    end = response_text.rfind('}')
    if start != -1 and end != -1:
        return response_text[start:end + 1]

    return response_text


def parse_resume_with_gemini(text: str) -> dict:
    """
    Sends extracted resume text to Gemini for structured extraction.

    Uses the same 7-component prompt framework as the invoice parser:
      1. Role / Persona
      2. Task
      3. Context
      4. Input Data
      5. Output Format
      6. Constraints
      7. Examples (few-shot)
    """
    try:
        client = genai.Client(http_options=HttpOptions(api_version="v1"))
    except Exception as e:
        print(f"Error initializing Gemini client: {e}")
        sys.exit(1)

    prompt = f"""
    # 1. ROLE / PERSONA
    You are a Senior HR Data Analyst and Expert Resume Intelligence Specialist.
    You have 15+ years of experience extracting structured candidate profiles from
    resumes in every format — single-column, multi-column, creative layouts, plain text.

    # 2. TASK
    Analyze the provided OCR-extracted text from a candidate's resume and map every
    relevant field into a precise, machine-readable JSON object.

    # 3. CONTEXT
    This is part of an automated Applicant Tracking System (ATS) pipeline.
    The output feeds directly into a relational SQLite database. Accuracy is critical:
    incorrect experience years or missing companies will affect candidate ranking.

    # 4. INPUT DATA
    The raw text was extracted from a PDF resume using pdfplumber. It may contain
    noisy whitespace, line-break artifacts, or merged columns.

    --- RESUME TEXT START ---
    {text}
    --- RESUME TEXT END ---

    # 5. OUTPUT FORMAT
    Return ONLY a valid JSON object matching this exact schema — no extra text:
    {{
        "name": "string — candidate's full name",
        "email": "string — contact email address",
        "phone_no": "string — contact phone number, preserve country codes and formatting",
        "experience_in_years": number — total professional experience as a decimal (e.g. 3.5),
        "skills": ["string", "..."] — flat list of technical and soft skills,
        "companies": [
            {{
                "company_name": "string — official organization name",
                "role": "string — job title / designation",
                "job_responsibilities": "string — key tasks and achievements, comma-separated"
            }}
        ],
        "projects": [
            {{
                "project_name": "string — title of the project",
                "project_description": "string — brief overview, tools used, outcomes"
            }}
        ]
    }}

    # 6. CONSTRAINTS
    - Output must be strict, valid JSON — parseable by Python's json.loads().
    - No preamble, postamble, or conversational text.
    - If a field is missing from the resume, use null for strings and 0 for numbers.
    - experience_in_years must be a NUMBER, never a string like "3 years".
    - skills must be a flat JSON array of strings, never a nested object.
    - Each company and project must be a separate object in its array.
    - Preserve original casing for names and companies.

    # 7. EXAMPLES (few-shot)
    Example Input Snippet:
      "Jane Doe | jane@email.com | +1-555-0100
       Software Engineer at Acme Corp (2021-2023)
       - Built REST APIs in Python  - Led a team of 4
       Project: SmartSearch — semantic search engine using BERT"

    Example Output:
    {{
        "name": "Jane Doe",
        "email": "jane@email.com",
        "phone_no": "+1-555-0100",
        "experience_in_years": 2,
        "skills": ["Python", "REST APIs", "Team Leadership", "BERT"],
        "companies": [
            {{
                "company_name": "Acme Corp",
                "role": "Software Engineer",
                "job_responsibilities": "Built REST APIs in Python, Led a team of 4"
            }}
        ],
        "projects": [
            {{
                "project_name": "SmartSearch",
                "project_description": "Semantic search engine using BERT"
            }}
        ]
    }}

    JSON Result:
    """

    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )
        cleaned = clean_json_response(response.text)
        return json.loads(cleaned)
    except Exception as e:
        print(f"Error during Gemini generation or JSON parsing: {e}")
        raw = response.text if 'response' in locals() else None
        return {"error": str(e), "raw_response": raw}


# ---------------------------------------------------------------------------
# Step 3 — Result Folder + Storage
# ---------------------------------------------------------------------------

def setup_result_folders(pdf_path: str) -> dict:
    """Creates a step-based folder structure for the output of each resume."""
    base_name = os.path.splitext(os.path.basename(pdf_path))[0]
    output_dir = f"results_{base_name}"

    step_folders = {
        "step1": os.path.join(output_dir, "step_1_ocr"),
        "step2": os.path.join(output_dir, "step_2_llm"),
        "step3": os.path.join(output_dir, "step_3_storage"),
    }

    for folder in step_folders.values():
        os.makedirs(folder, exist_ok=True)

    return step_folders


def process_single_resume(pdf_path: str):
    """Full pipeline for a single resume PDF."""
    folders = setup_result_folders(pdf_path)

    # ── Step 1: OCR ──────────────────────────────────────────────────────────
    print(f"\n--- Step 1: Extracting text from {pdf_path} ---")
    extracted_text = extract_text_from_pdf(pdf_path)

    if not extracted_text.strip():
        print("Warning: No text could be extracted from the PDF. Skipping.")
        return

    print(f"Extracted {len(extracted_text)} characters.")
    raw_text_path = os.path.join(folders["step1"], "raw_extracted_text.txt")
    with open(raw_text_path, "w", encoding="utf-8") as f:
        f.write(extracted_text)
    print(f"-> Raw text saved to: {raw_text_path}")

    # ── Step 2: LLM Parsing ───────────────────────────────────────────────────
    print("--- Step 2: Parsing with Gemini (7-Component Prompt) ---")
    extracted_data = parse_resume_with_gemini(extracted_text)

    parsed_json_path = os.path.join(folders["step2"], "parsed_candidate.json")
    with open(parsed_json_path, "w", encoding="utf-8") as f:
        json.dump(extracted_data, f, indent=4)
    print(f"-> Parsed JSON saved to: {parsed_json_path}")

    # ── Step 3: Storage ───────────────────────────────────────────────────────
    if "error" not in extracted_data:
        print("--- Step 3: Saving to candidates.json and candidates.db ---")
        storage = ResumeStorage()
        storage.save_to_json(extracted_data)
        storage.save_to_sqlite(extracted_data)

        storage_log_path = os.path.join(folders["step3"], "storage_log.txt")
        with open(storage_log_path, "w", encoding="utf-8") as f:
            f.write(f"Status: Success\n")
            f.write(f"Candidate Name: {extracted_data.get('name')}\n")
            f.write(f"Email: {extracted_data.get('email')}\n")
            f.write(f"Stored in: candidates.json and candidates.db\n")
        print(f"-> Storage log saved to: {storage_log_path}")
    else:
        print("Skipping storage due to parsing error.")
        print(f"  Error: {extracted_data.get('error')}")


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python resume_parser.py <path_to_resume.pdf>")
        print("  python resume_parser.py <path_to_directory_of_pdfs>")
        print("")
        print("Examples:")
        print("  python resume_parser.py resume.pdf")
        print("  python resume_parser.py ./resumes/")
        sys.exit(1)

    input_path = sys.argv[1]

    if not os.path.exists(input_path):
        print(f"Error: Path '{input_path}' not found.")
        sys.exit(1)

    if os.path.isfile(input_path):
        if input_path.lower().endswith(".pdf"):
            process_single_resume(input_path)
        else:
            print("Error: The provided file is not a PDF.")
            sys.exit(1)

    elif os.path.isdir(input_path):
        print(f"\n--- Batch Processing Mode: {input_path} ---")
        pdf_files = [f for f in os.listdir(input_path) if f.lower().endswith(".pdf")]

        if not pdf_files:
            print("No PDF files found in the directory.")
        else:
            print(f"Found {len(pdf_files)} PDF(s). Starting pipeline...\n")
            for pdf_file in pdf_files:
                full_path = os.path.join(input_path, pdf_file)
                process_single_resume(full_path)
            print("\n--- Batch Processing Completed ---")
