"""
view_db.py — View stored candidates from candidates.db
Mirrors the invoice_parser's view_db.py pattern.

Usage:
  python view_db.py              # List all candidates (summary)
  python view_db.py --full       # Full detail including companies and projects
  python view_db.py --id 3       # Show one candidate by ID
"""

import sqlite3
import json
import sys

DB_PATH = "candidates.db"


def get_connection():
    try:
        return sqlite3.connect(DB_PATH)
    except Exception as e:
        print(f"Error connecting to {DB_PATH}: {e}")
        sys.exit(1)


def list_candidates():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, name, email, phone_no, experience_in_years, created_at FROM candidates ORDER BY id"
    )
    rows = cursor.fetchall()
    conn.close()

    if not rows:
        print("No candidates found in the database.")
        return

    print(f"\n{'ID':<5} {'Name':<25} {'Email':<30} {'Phone':<18} {'Exp (yrs)':<12} {'Parsed At'}")
    print("-" * 105)
    for row in rows:
        print(f"{row[0]:<5} {str(row[1]):<25} {str(row[2]):<30} {str(row[3]):<18} {str(row[4]):<12} {row[5]}")
    print(f"\nTotal: {len(rows)} candidate(s)\n")


def show_candidate_full(candidate_id: int):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM candidates WHERE id = ?", (candidate_id,))
    row = cursor.fetchone()

    if not row:
        print(f"No candidate found with ID {candidate_id}.")
        conn.close()
        return

    print(f"\n{'='*60}")
    print(f"  Candidate #{row[0]}: {row[1]}")
    print(f"{'='*60}")
    print(f"  Email            : {row[2]}")
    print(f"  Phone            : {row[3]}")
    print(f"  Experience (yrs) : {row[4]}")
    skills = json.loads(row[5]) if row[5] else []
    print(f"  Skills           : {', '.join(skills) if skills else 'N/A'}")
    print(f"  Parsed At        : {row[7]}")

    # Companies
    cursor.execute(
        "SELECT company_name, role, job_responsibilities FROM companies WHERE candidate_id = ?",
        (candidate_id,)
    )
    companies = cursor.fetchall()
    if companies:
        print(f"\n  Work Experience:")
        for c in companies:
            print(f"    • {c[1]} @ {c[0]}")
            print(f"      {c[2]}")

    # Projects
    cursor.execute(
        "SELECT project_name, project_description FROM projects WHERE candidate_id = ?",
        (candidate_id,)
    )
    projects = cursor.fetchall()
    if projects:
        print(f"\n  Projects:")
        for p in projects:
            print(f"    • {p[0]}: {p[1]}")

    print()
    conn.close()


def show_all_full():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM candidates ORDER BY id")
    ids = [row[0] for row in cursor.fetchall()]
    conn.close()

    if not ids:
        print("No candidates found.")
        return

    for cid in ids:
        show_candidate_full(cid)


if __name__ == "__main__":
    args = sys.argv[1:]

    if not args:
        list_candidates()
    elif "--full" in args:
        show_all_full()
    elif "--id" in args:
        idx = args.index("--id")
        if idx + 1 < len(args):
            try:
                cid = int(args[idx + 1])
                show_candidate_full(cid)
            except ValueError:
                print("Error: --id must be followed by an integer.")
        else:
            print("Error: --id requires a candidate ID number.")
    else:
        print(__doc__)
