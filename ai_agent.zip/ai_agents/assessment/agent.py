import os

from dotenv import load_dotenv
from google.adk.agents import LlmAgent

from .tools import (
    # Products
    get_products_tool, add_product_tool,
    update_product_tool, delete_product_tool,
    # Carts
    get_carts_tool, add_cart_tool,
    update_cart_tool, delete_cart_tool,
    # Users
    get_users_tool, add_user_tool,
    update_user_tool, delete_user_tool,
)

load_dotenv()


if not os.getenv("GOOGLE_API_KEY"):
    raise ValueError("GOOGLE_API_KEY is not set. Add it to your .env file.")


# ---------------------------------------------------------------------------
# Task 3a — Products Agent
# ---------------------------------------------------------------------------

products_agent = LlmAgent(
    name="products_agent",
    model="gemini-2.5-flash",
    description=(
        "Handles all product-related operations for the Fake Store: "
        "listing, creating, updating, and deleting products."
    ),
    instruction="""
    You are a specialized Products Agent for the Fake Store e-commerce platform.
    You manage the product catalogue using the Fake Store API.

    Your capabilities:
    - GET    → use get_products_tool   (list all, or fetch one by ID)
    - POST   → use add_product_tool    (create a new product)
    - PATCH  → use update_product_tool (update fields of an existing product)
    - DELETE → use delete_product_tool (remove a product by ID)

    Always return the API response clearly formatted for the user.
    If an ID is needed and not provided, ask the user for it before proceeding.
    """,
    tools=[
        get_products_tool,
        add_product_tool,
        update_product_tool,
        delete_product_tool,
    ],
)


# ---------------------------------------------------------------------------
# Task 3b — Carts Agent
# ---------------------------------------------------------------------------

carts_agent = LlmAgent(
    name="carts_agent",
    model="gemini-2.5-flash",
    description=(
        "Handles all shopping cart operations for the Fake Store: "
        "viewing, creating, updating, and deleting carts."
    ),
    instruction="""
    You are a specialized Carts Agent for the Fake Store e-commerce platform.
    You manage shopping carts using the Fake Store API.

    Your capabilities:
    - GET    → use get_carts_tool    (list all carts, or fetch one by ID)
    - POST   → use add_cart_tool     (create a new cart with userId, date, products)
    - PATCH  → use update_cart_tool  (update an existing cart's contents)
    - DELETE → use delete_cart_tool  (remove a cart by ID)

    When creating a cart, products should be a list like:
    [{"productId": 1, "quantity": 2}, {"productId": 3, "quantity": 1}]

    Always return the API response clearly formatted for the user.
    If a cart ID is needed and not provided, ask the user for it.
    """,
    tools=[
        get_carts_tool,
        add_cart_tool,
        update_cart_tool,
        delete_cart_tool,
    ],
)


# ---------------------------------------------------------------------------
# Task 3c — Users Agent
# ---------------------------------------------------------------------------

users_agent = LlmAgent(
    name="users_agent",
    model="gemini-2.5-flash",
    description=(
        "Handles all user profile operations for the Fake Store: "
        "listing, registering, updating, and deleting users."
    ),
    instruction="""
    You are a specialized Users Agent for the Fake Store e-commerce platform.
    You manage user profiles using the Fake Store API.

    Your capabilities:
    - GET    → use get_users_tool    (list all users, or fetch one by ID)
    - POST   → use add_user_tool     (register a new user with email, username,
                                      password, firstname, lastname, phone)
    - PATCH  → use update_user_tool  (update fields of an existing user profile)
    - DELETE → use delete_user_tool  (remove a user by ID)

    Always return the API response clearly formatted for the user.
    Never expose or log passwords in your responses.
    If a user ID is needed and not provided, ask the user for it.
    """,
    tools=[
        get_users_tool,
        add_user_tool,
        update_user_tool,
        delete_user_tool,
    ],
)


# ---------------------------------------------------------------------------
# Task 4 — Root / Coordinator Agent
# ---------------------------------------------------------------------------

root_agent = LlmAgent(
    name="FakeStore_Root_Agent",
    model="gemini-2.5-flash",
    description="Master agent that coordinates all Fake Store API operations.",
    instruction="""
    You are the master coordinator for the Fake Store e-commerce platform.
    You manage three specialized sub-agents and route every user request to
    the correct one based on what the user is asking about.

    Routing rules:
    - Any request about PRODUCTS (listing, creating, updating, deleting items
      in the catalogue) → delegate to products_agent.
    - Any request about CARTS (shopping carts, cart items, purchases)
      → delegate to carts_agent.
    - Any request about USERS (user profiles, registration, login details)
      → delegate to users_agent.

    If a request is ambiguous, ask the user one short clarifying question.
    After the sub-agent responds, present the result to the user in a clear,
    friendly format. Do not perform API calls yourself — always delegate.

    Examples:
    - "Show me all products"          → products_agent
    - "Add a new laptop to the store" → products_agent
    - "What's in cart 3?"             → carts_agent
    - "Create a cart for user 2"      → carts_agent
    - "List all users"                → users_agent
    - "Register a new user"           → users_agent
    """,
    sub_agents=[
        products_agent,
        carts_agent,
        users_agent,
    ],
)
