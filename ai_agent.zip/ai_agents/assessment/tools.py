import json
import requests

from google.adk.tools.function_tool import FunctionTool

BASE_URL = "https://fakestoreapi.com"


# ---------------------------------------------------------------------------
# Core HTTP helper
# ---------------------------------------------------------------------------

def _request(method: str, path: str, payload: dict = None) -> str:
    """Internal helper that fires an HTTP request and returns a JSON string."""
    url = f"{BASE_URL}/{path.strip('/')}"
    try:
        if method == "GET":
            response = requests.get(url, timeout=10)
        elif method == "POST":
            response = requests.post(url, json=payload, timeout=10)
        elif method == "PATCH":
            response = requests.patch(url, json=payload, timeout=10)
        elif method == "DELETE":
            response = requests.delete(url, timeout=10)
        else:
            return json.dumps({"error": f"Unsupported HTTP method: {method}"})

        response.raise_for_status()
        return response.text

    except requests.exceptions.HTTPError as e:
        return json.dumps({"error": f"HTTP {response.status_code}: {str(e)}"})
    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Products tools
# ---------------------------------------------------------------------------

def get_products(product_id: str = "") -> str:
    """
    Fetch products from the Fake Store API.

    Args:
        product_id: Leave empty to get all products, or provide an ID (e.g. '1')
                    to get a single product.

    Returns:
        JSON string with product(s) data.
    """
    path = f"products/{product_id}" if product_id else "products"
    return _request("GET", path)


def add_product(title: str, price: float, description: str,
                category: str, image: str) -> str:
    """
    Add a new product to the Fake Store.

    Args:
        title:       Product title.
        price:       Product price (number).
        description: Short product description.
        category:    Category name (e.g. 'electronics').
        image:       URL of the product image.

    Returns:
        JSON string with the created product including its new ID.
    """
    payload = {
        "title": title,
        "price": price,
        "description": description,
        "category": category,
        "image": image,
    }
    return _request("POST", "products", payload)


def update_product(product_id: str, title: str = "", price: float = None,
                   description: str = "", category: str = "", image: str = "") -> str:
    """
    Partially update an existing product (PATCH).

    Args:
        product_id:  ID of the product to update.
        title:       New title (optional).
        price:       New price (optional).
        description: New description (optional).
        category:    New category (optional).
        image:       New image URL (optional).

    Returns:
        JSON string with the updated product data.
    """
    payload = {}
    if title:        payload["title"]       = title
    if price:        payload["price"]       = price
    if description:  payload["description"] = description
    if category:     payload["category"]    = category
    if image:        payload["image"]       = image
    return _request("PATCH", f"products/{product_id}", payload)


def delete_product(product_id: str) -> str:
    """
    Delete a product by its ID.

    Args:
        product_id: ID of the product to delete.

    Returns:
        JSON string confirming deletion.
    """
    return _request("DELETE", f"products/{product_id}")


# ---------------------------------------------------------------------------
# Carts tools
# ---------------------------------------------------------------------------

def get_carts(cart_id: str = "") -> str:
    """
    Fetch shopping carts from the Fake Store API.

    Args:
        cart_id: Leave empty to get all carts, or provide an ID (e.g. '1')
                 to get a specific cart.

    Returns:
        JSON string with cart(s) data.
    """
    path = f"carts/{cart_id}" if cart_id else "carts"
    return _request("GET", path)


def add_cart(user_id: int, date: str, products: list) -> str:
    """
    Create a new shopping cart.

    Args:
        user_id:  ID of the user who owns the cart.
        date:     Purchase date in YYYY-MM-DD format.
        products: List of dicts with 'productId' and 'quantity' keys.
                  Example: [{"productId": 1, "quantity": 2}]

    Returns:
        JSON string with the created cart including its new ID.
    """
    payload = {
        "userId": user_id,
        "date": date,
        "products": products,
    }
    return _request("POST", "carts", payload)


def update_cart(cart_id: str, user_id: int = None,
                date: str = "", products: list = None) -> str:
    """
    Partially update an existing cart (PATCH).

    Args:
        cart_id:  ID of the cart to update.
        user_id:  New user ID (optional).
        date:     New date in YYYY-MM-DD format (optional).
        products: New products list (optional).

    Returns:
        JSON string with the updated cart data.
    """
    payload = {}
    if user_id:   payload["userId"]   = user_id
    if date:      payload["date"]     = date
    if products:  payload["products"] = products
    return _request("PATCH", f"carts/{cart_id}", payload)


def delete_cart(cart_id: str) -> str:
    """
    Delete a cart by its ID.

    Args:
        cart_id: ID of the cart to delete.

    Returns:
        JSON string confirming deletion.
    """
    return _request("DELETE", f"carts/{cart_id}")


# ---------------------------------------------------------------------------
# Users tools
# ---------------------------------------------------------------------------

def get_users(user_id: str = "") -> str:
    """
    Fetch users from the Fake Store API.

    Args:
        user_id: Leave empty to get all users, or provide an ID (e.g. '1')
                 to get a specific user.

    Returns:
        JSON string with user(s) data.
    """
    path = f"users/{user_id}" if user_id else "users"
    return _request("GET", path)


def add_user(email: str, username: str, password: str,
             firstname: str, lastname: str, phone: str) -> str:
    """
    Register a new user.

    Args:
        email:     User's email address.
        username:  Unique username.
        password:  User's password.
        firstname: First name.
        lastname:  Last name.
        phone:     Contact phone number.

    Returns:
        JSON string with the created user including their new ID.
    """
    payload = {
        "email": email,
        "username": username,
        "password": password,
        "name": {"firstname": firstname, "lastname": lastname},
        "phone": phone,
    }
    return _request("POST", "users", payload)


def update_user(user_id: str, email: str = "", username: str = "",
                password: str = "", firstname: str = "",
                lastname: str = "", phone: str = "") -> str:
    """
    Partially update an existing user profile (PATCH).

    Args:
        user_id:   ID of the user to update.
        email:     New email (optional).
        username:  New username (optional).
        password:  New password (optional).
        firstname: New first name (optional).
        lastname:  New last name (optional).
        phone:     New phone number (optional).

    Returns:
        JSON string with the updated user data.
    """
    payload = {}
    if email:     payload["email"]    = email
    if username:  payload["username"] = username
    if password:  payload["password"] = password
    if phone:     payload["phone"]    = phone
    if firstname or lastname:
        payload["name"] = {}
        if firstname: payload["name"]["firstname"] = firstname
        if lastname:  payload["name"]["lastname"]  = lastname
    return _request("PATCH", f"users/{user_id}", payload)


def delete_user(user_id: str) -> str:
    """
    Delete a user by their ID.

    Args:
        user_id: ID of the user to delete.

    Returns:
        JSON string confirming deletion.
    """
    return _request("DELETE", f"users/{user_id}")


# ---------------------------------------------------------------------------
# FunctionTool wrappers (used by agents)
# ---------------------------------------------------------------------------

# Products
get_products_tool    = FunctionTool(get_products)
add_product_tool     = FunctionTool(add_product)
update_product_tool  = FunctionTool(update_product)
delete_product_tool  = FunctionTool(delete_product)

# Carts
get_carts_tool    = FunctionTool(get_carts)
add_cart_tool     = FunctionTool(add_cart)
update_cart_tool  = FunctionTool(update_cart)
delete_cart_tool  = FunctionTool(delete_cart)

# Users
get_users_tool    = FunctionTool(get_users)
add_user_tool     = FunctionTool(add_user)
update_user_tool  = FunctionTool(update_user)
delete_user_tool  = FunctionTool(delete_user)
