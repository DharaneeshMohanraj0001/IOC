# AI Agents — Fake Store API Assessment

A multi-agent system built with **Google ADK + Gemini** that manages an
e-commerce platform via the [Fake Store API](https://fakestoreapi.com/docs).

## Architecture

```
User Prompt
    ↓
FakeStore_Root_Agent  (coordinator)
    ├── products_agent  →  GET / POST / PATCH / DELETE  /products
    ├── carts_agent     →  GET / POST / PATCH / DELETE  /carts
    └── users_agent     →  GET / POST / PATCH / DELETE  /users
```

## Project Structure

```
assessment/
├── agent.py          ← Root agent + 3 specialized sub-agents
├── tools.py          ← All Fake Store API FunctionTools (12 tools)
├── __init__.py       ← ADK package entry point
├── .env.example      ← Copy to .env and add your API key
└── README.md         ← This file
```

## Setup

### 1. Install dependencies
```bash
pip install google-adk python-dotenv requests
```

### 2. Configure API key
```bash
cp .env.example .env
# Open .env and set:
# GOOGLE_API_KEY=your_key_here
```

Get a key at: https://aistudio.google.com/apikey

## Running the Agent

Run from the **parent** `ai_agents/` directory (ADK requires this):

```bash
cd ..                         # go up to ai_agents/
adk web assessment            # launch browser UI
```

Open: http://127.0.0.1:8000

## Tools Reference (`tools.py`)

### Products (4 tools)
| Tool | Method | Endpoint |
|---|---|---|
| `get_products_tool`   | GET    | `/products` or `/products/{id}` |
| `add_product_tool`    | POST   | `/products` |
| `update_product_tool` | PATCH  | `/products/{id}` |
| `delete_product_tool` | DELETE | `/products/{id}` |

### Carts (4 tools)
| Tool | Method | Endpoint |
|---|---|---|
| `get_carts_tool`   | GET    | `/carts` or `/carts/{id}` |
| `add_cart_tool`    | POST   | `/carts` |
| `update_cart_tool` | PATCH  | `/carts/{id}` |
| `delete_cart_tool` | DELETE | `/carts/{id}` |

### Users (4 tools)
| Tool | Method | Endpoint |
|---|---|---|
| `get_users_tool`   | GET    | `/users` or `/users/{id}` |
| `add_user_tool`    | POST   | `/users` |
| `update_user_tool` | PATCH  | `/users/{id}` |
| `delete_user_tool` | DELETE | `/users/{id}` |

## Example Prompts

```
Show me all products
Get product with ID 3
Add a new product: title=Gaming Mouse, price=49.99, category=electronics
Update product 5 title to "Wireless Keyboard"
Delete product 2

Show all carts
Create a cart for user 1 with product 3 (qty 2) for 2024-06-01
What's in cart 4?

List all users
Register a new user: email=john@example.com, username=john99
Get user with ID 2
Delete user 5
```

## Agent Routing Logic

The `FakeStore_Root_Agent` reads the user's intent and routes:

| Keywords in query | Routed to |
|---|---|
| product, item, catalogue, store, price, category | `products_agent` |
| cart, basket, purchase, order | `carts_agent` |
| user, profile, register, account, login | `users_agent` |
